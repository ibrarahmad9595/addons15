# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_website_crm
from . import test_website_visitor
from . import test_crm_lead_merge
