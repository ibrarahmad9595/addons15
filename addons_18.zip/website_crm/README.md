Your Contact Form
-----------------

### Integrate contact forms with your leads

This simple application integrates a contact form in your "Contact us" page.
Forms submissions create leads automatically in <a href="https://www.odoo.com/app/crm">Odoo CRM</a>.

Easy Contact Page
-----------------

Get your leads filled up automatically with your contact form integration. This
application allows a better qualification of the lead which is perfect to link
them to marketing campaigns.

