odoo.define("web.public_env", function (require) {
    "use strict";

    /**
     * This file defines the env to use in the public side.
     */

    const commonEnv = require("web.commonEnv");

    return commonEnv;
});
