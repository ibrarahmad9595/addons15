/** @odoo-module alias=root.widget */
import { PublicRoot, createPublicRoot } from "./public_root";

export default createPublicRoot(PublicRoot);
