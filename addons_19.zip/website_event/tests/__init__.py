# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_event_menus
from . import test_event_visitor
from . import test_website_event
