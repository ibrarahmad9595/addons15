odoo.define('web_studio.CalendarEditor', function (require) {
"use strict";

var CalendarRenderer = require('web.CalendarRenderer');

var EditorMixin = require('web_studio.EditorMixin');

return CalendarRenderer.extend(EditorMixin, {
});

});
