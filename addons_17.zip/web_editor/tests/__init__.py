# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_controller
from . import test_converter
from . import test_odoo_editor
from . import test_views
