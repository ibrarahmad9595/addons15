Gauge for Kanban module documentation
======================================

Changelog
'''''''''

.. toctree::
   :maxdepth: 1

   changelog.rst
