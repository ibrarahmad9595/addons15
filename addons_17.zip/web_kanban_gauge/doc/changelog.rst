.. _changelog:

Changelog
=========

`trunk (saas-2)`
----------------

 - Module ``web_kanban_gauge`` created. It comes from the refactoring of
   custom kanban widgets used in other modules, now standardized.
