# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import delivery_carrier
from . import delivery_grid
from . import product_template
from . import sale_order
from . import partner
from . import stock_move
from . import stock_picking
from . import stock_package_type
