# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import crm_lead
from . import crm_iap_lead_helpers
from . import crm_iap_lead_industry
from . import crm_iap_lead_role
from . import crm_iap_lead_seniority
from . import crm_iap_lead_mining_request
