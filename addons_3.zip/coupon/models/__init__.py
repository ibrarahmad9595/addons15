# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mail_compose_message
from . import coupon
from . import coupon_reward
from . import coupon_rules
from . import coupon_program
from . import product_product
