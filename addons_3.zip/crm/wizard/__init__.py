# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import crm_lead_lost
from . import crm_lead_to_opportunity
from . import crm_lead_to_opportunity_mass
from . import crm_merge_opportunities
from . import crm_lead_pls_update
