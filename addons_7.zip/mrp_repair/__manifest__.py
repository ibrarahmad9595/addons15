# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Mrp Repairs',
    'version': '1.0',
    'category': 'Inventory/Inventory',
    'depends': ['repair', 'mrp'],
    'installable': True,
    'auto_install': True,
    'application': False,
    'license': 'LGPL-3',
}
