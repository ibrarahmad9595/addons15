# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import stock_move
from . import stock_picking
from . import res_company
from . import stock_warehouse
from . import purchase
from . import stock_rule
