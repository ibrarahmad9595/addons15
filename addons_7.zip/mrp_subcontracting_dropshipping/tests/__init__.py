#  -*- coding: utf-8 -*-
#  Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_purchase_subcontracting
from . import test_sale_dropshipping
from . import test_anglo_saxon_valuation
