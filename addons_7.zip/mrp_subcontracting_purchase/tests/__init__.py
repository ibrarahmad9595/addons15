# -*- coding: utf-8 -*-

from . import test_mrp_subcontracting_purchase
