# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_commissions
from . import test_purchase_order
from . import test_sale_order
from . import test_sale_subscription
