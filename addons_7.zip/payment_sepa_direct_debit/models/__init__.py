# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move_line
from . import account_payment_method
from . import payment_acquirer
from . import payment_token
from . import payment_transaction
from . import res_partner
from . import sdd_mandate
