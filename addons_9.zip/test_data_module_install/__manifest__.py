{
    'name': 'test installation of data module',
    'description': 'Test data module (see test_data_module) installation',
    'version': '0.0.1',
    'category': 'Hidden/Tests',
    'sequence': 10,
    'license': 'LGPL-3',
}
