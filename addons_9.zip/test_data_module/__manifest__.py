{
    'name': 'test module to test data only modules',
    'description': 'Fake module to test data module installation without __init__.py',
    'version': '0.0.1',
    'category': 'Hidden/Tests',
    'sequence': 0,
    'license': 'LGPL-3',
}
