# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_crossdock
from . import test_dropship
from . import test_lifo_price
from . import test_procurement_exception
from . import test_stockvaluation
