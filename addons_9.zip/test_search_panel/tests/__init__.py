# -*- coding: utf-8 -*-
from . import test_search_panel_select_range
from . import test_search_panel_select_multi_range
