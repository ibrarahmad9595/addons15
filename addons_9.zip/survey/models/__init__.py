# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import survey_survey
from . import survey_question
from . import survey_user_input
from . import badge
from . import challenge
from . import res_partner
