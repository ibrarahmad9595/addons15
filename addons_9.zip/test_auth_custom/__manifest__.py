# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Tests that custom auth works & is not impaired by CORS',
    'category': 'Hidden',
    'data': [],
    'license': 'LGPL-3',
}
