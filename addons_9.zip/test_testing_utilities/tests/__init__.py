# -*- coding: utf-8 -*-
from . import test_methods
from . import test_lxml
from . import test_form_impl
from . import test_xml_tools
from . import test_env
