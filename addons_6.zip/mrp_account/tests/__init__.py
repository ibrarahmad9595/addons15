# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import test_analytic_account
from . import test_mrp_account
from . import test_bom_price
from . import test_valuation_layers
