# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import analytic_account
from . import mrp_bom
from . import mrp_workcenter
from . import mrp_workorder
from . import mrp_production
from . import product
from . import stock_move
from . import stock_rule
from . import account_move
