# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mrp_report_bom_structure
from . import report_stock_forecasted
from . import report_stock_reception
from . import report_stock_rule
