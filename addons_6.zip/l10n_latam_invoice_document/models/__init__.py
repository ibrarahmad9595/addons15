# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_company
from . import l10n_latam_document_type
from . import account_journal
from . import account_move
from . import account_move_line
from . import account_chart_template
