# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import fleet_service_type
from . import fleet_vehicle
from . import fleet_vehicle_assignation_log
from . import fleet_vehicle_log_contract
from . import fleet_vehicle_log_services
from . import fleet_vehicle_model
from . import fleet_vehicle_model_brand
from . import fleet_vehicle_model_category
from . import fleet_vehicle_odometer
from . import fleet_vehicle_state
from . import fleet_vehicle_tag
from . import res_config_settings
from . import res_partner
