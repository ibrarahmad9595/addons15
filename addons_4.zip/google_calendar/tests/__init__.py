# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_sync_common
from . import test_sync_google2odoo
from . import test_sync_odoo2google
