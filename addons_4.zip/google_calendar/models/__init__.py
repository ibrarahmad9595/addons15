# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_config_settings
from . import google_sync
from . import calendar
from . import calendar_recurrence_rule
from . import res_users
from . import calendar_attendee
from . import google_credentials
