# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import event_lead_rule
from . import event_registration
from . import crm_lead
from . import event_event
