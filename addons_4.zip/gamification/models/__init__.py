# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import goal
from . import challenge
from . import badge
from . import gamification_karma_rank
from . import gamification_karma_tracking
from . import res_users
