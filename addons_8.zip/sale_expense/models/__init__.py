# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_expense
from . import sale_order
from . import product_template
from . import account_move
