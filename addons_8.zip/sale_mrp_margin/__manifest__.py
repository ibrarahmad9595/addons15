# -*- coding: utf-8 -*-
{
    'name': "Sale Mrp Margin",
    'category': 'Sales/Sales',
    'version': '0.1',
    'description': 'Handle BoM prices to compute sale margin.',
    'depends': ['sale_mrp', 'sale_stock_margin'],
    'license': 'LGPL-3',
}
