# -*- coding: utf-8 -*-
{
    'name': "Account TaxCloud - Sale",
    'summary': """""",
    'description': """
    """,
    'category': 'Accounting/Accounting',
    'depends': ['account_taxcloud', 'sale'],
    'data': [
        'views/sale_order_views.xml',
    ],
    'auto_install': True,
    'license': 'OEEL-1',
}
