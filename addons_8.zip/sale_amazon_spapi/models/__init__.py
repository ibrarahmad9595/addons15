# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import amazon_account
from . import amazon_marketplace
from . import stock_picking
