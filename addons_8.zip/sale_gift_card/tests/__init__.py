# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_buy_gift_card
from . import test_pay_with_gift_card
