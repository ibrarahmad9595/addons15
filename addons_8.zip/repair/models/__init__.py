# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import repair
from . import stock_traceability
from . import stock_production_lot
from . import account_move
from . import product
