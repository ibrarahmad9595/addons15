# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import approval_activity
from . import approval_category
from . import approval_category_approver
from . import approval_product_line
from . import approval_request
