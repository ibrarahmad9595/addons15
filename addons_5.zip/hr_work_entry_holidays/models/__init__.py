# -*- coding: utf-8 -*-

from . import hr_contract
from . import hr_leave
from . import hr_work_entry
