# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import l10n_in_hr_payroll
from . import hr_employee
