# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_payment_advice
from . import test_payment_advice_batch
