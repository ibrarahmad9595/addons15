# -*- coding: utf-8 -*

from . import res_users
from . import res_partner
from . import im_livechat_channel
from . import mail_channel
from . import mail_channel_partner
from . import mail_message
from . import res_users_settings
from . import rating
from . import digest
