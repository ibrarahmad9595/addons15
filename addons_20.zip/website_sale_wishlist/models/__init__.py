# -*- coding: utf-8 -*-
from . import product_wishlist
from . import res_users
